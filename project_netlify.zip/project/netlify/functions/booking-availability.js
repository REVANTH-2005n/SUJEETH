import mongoose from "mongoose";
import { connectDB } from "./db.js";

const bookingSchema = new mongoose.Schema({
  restaurantId: String,
  tableId: String,
  tableNumber: Number,
  date: String,
  time: String,
  endTime: String,
  customerName: String,
  customerEmail: String,
  customerPhone: String,
});
const Booking = mongoose.models.Booking || mongoose.model("Booking", bookingSchema);

export const handler = async (event) => {
  if (event.httpMethod !== "GET") {
    return { statusCode: 405, body: JSON.stringify({ message: "Method not allowed" }) };
  }

  try {
    await connectDB();
    const { restaurantId, date } = event.queryStringParameters || {};

    if (!restaurantId || !date)
      return { statusCode: 400, body: JSON.stringify({ message: "restaurantId and date are required" }) };

    const bookings = await Booking.find({ restaurantId, date }).sort({ time: 1 });

    return { statusCode: 200, body: JSON.stringify(bookings) };
  } catch (error) {
    console.error(error);
    return { statusCode: 500, body: JSON.stringify({ message: "Server error" }) };
  }
};
