import mongoose from "mongoose";
import { connectDB } from "./db.js";

const bookingSchema = new mongoose.Schema({
  restaurantId: String,
  tableId: String,
  tableNumber: Number,
  date: String,
  time: String,
  endTime: String,
  customerName: String,
  customerEmail: String,
  customerPhone: String,
});
const Booking = mongoose.models.Booking || mongoose.model("Booking", bookingSchema);

export const handler = async (event) => {
  if (event.httpMethod !== "DELETE") {
    return { statusCode: 405, body: JSON.stringify({ message: "Method not allowed" }) };
  }

  try {
    await connectDB();
    // ID is passed as a query param: /booking-cancel?id=...
    const { id } = event.queryStringParameters || {};

    if (!id)
      return { statusCode: 400, body: JSON.stringify({ message: "Booking ID is required" }) };

    const deleted = await Booking.findByIdAndDelete(id);

    if (!deleted)
      return { statusCode: 404, body: JSON.stringify({ message: "Booking not found" }) };

    return { statusCode: 200, body: JSON.stringify({ message: "Booking cancelled successfully" }) };
  } catch (error) {
    console.error(error);
    return { statusCode: 500, body: JSON.stringify({ message: "Server error" }) };
  }
};
