import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import { connectDB } from "./db.js";

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});
const User = mongoose.models.User || mongoose.model("User", userSchema);

export const handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ message: "Method not allowed" }) };
  }

  try {
    await connectDB();
    const { name, email, password } = JSON.parse(event.body);

    if (!name || !email || !password)
      return { statusCode: 400, body: JSON.stringify({ message: "All fields are required" }) };

    const existingUser = await User.findOne({ email });
    if (existingUser)
      return { statusCode: 400, body: JSON.stringify({ message: "Email already exists" }) };

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ name, email, password: hashedPassword });
    await newUser.save();

    return { statusCode: 201, body: JSON.stringify({ message: "User registered successfully" }) };
  } catch (error) {
    console.error(error);
    return { statusCode: 500, body: JSON.stringify({ message: "Server error" }) };
  }
};
