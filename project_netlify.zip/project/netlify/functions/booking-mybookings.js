import mongoose from "mongoose";
import { connectDB } from "./db.js";

const bookingSchema = new mongoose.Schema({
  restaurantId: String,
  tableId: String,
  tableNumber: Number,
  date: String,
  time: String,
  endTime: String,
  customerName: String,
  customerEmail: String,
  customerPhone: String,
});
const Booking = mongoose.models.Booking || mongoose.model("Booking", bookingSchema);

export const handler = async (event) => {
  if (event.httpMethod !== "GET") {
    return { statusCode: 405, body: JSON.stringify({ message: "Method not allowed" }) };
  }

  try {
    await connectDB();
    const { email, phone } = event.queryStringParameters || {};

    if (!email && !phone)
      return { statusCode: 400, body: JSON.stringify({ message: "Email or Phone is required" }) };

    const bookings = await Booking.find({
      $or: [{ customerEmail: email }, { customerPhone: phone }],
    }).sort({ date: 1, time: 1 });

    return { statusCode: 200, body: JSON.stringify(bookings) };
  } catch (error) {
    console.error(error);
    return { statusCode: 500, body: JSON.stringify({ message: "Server error" }) };
  }
};
