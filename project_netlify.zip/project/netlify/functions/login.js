import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { connectDB } from "./db.js";

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});
const User = mongoose.models.User || mongoose.model("User", userSchema);

export const handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ message: "Method not allowed" }) };
  }

  try {
    await connectDB();
    const { email, password } = JSON.parse(event.body);

    if (!email || !password)
      return { statusCode: 400, body: JSON.stringify({ message: "All fields are required" }) };

    const user = await User.findOne({ email });
    if (!user)
      return { statusCode: 400, body: JSON.stringify({ message: "Invalid email or password" }) };

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return { statusCode: 400, body: JSON.stringify({ message: "Invalid email or password" }) };

    const token = jwt.sign({ userId: user._id }, "secret123", { expiresIn: "7d" });

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Login successful",
        token,
        user: { id: user._id, name: user.name, email: user.email },
      }),
    };
  } catch (error) {
    console.error(error);
    return { statusCode: 500, body: JSON.stringify({ message: "Server error" }) };
  }
};
