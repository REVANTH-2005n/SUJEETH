import mongoose from "mongoose";
import { connectDB } from "./db.js";

const bookingSchema = new mongoose.Schema({
  restaurantId: String,
  tableId: String,
  tableNumber: Number,
  date: String,
  time: String,
  endTime: String,
  customerName: String,
  customerEmail: String,
  customerPhone: String,
});
const Booking = mongoose.models.Booking || mongoose.model("Booking", bookingSchema);

function overlaps(start1, end1, start2, end2) {
  return start1 < end2 && start2 < end1;
}

export const handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ message: "Method not allowed" }) };
  }

  try {
    await connectDB();
    const { restaurantId, tableId, tableNumber, date, time, endTime, customerName, customerEmail, customerPhone } =
      JSON.parse(event.body);

    if (!restaurantId || !tableId || !date || !time || !endTime)
      return { statusCode: 400, body: JSON.stringify({ message: "Missing required fields" }) };

    const existing = await Booking.find({ tableId, date });
    const conflict = existing.find((b) => overlaps(time, endTime, b.time, b.endTime));

    if (conflict)
      return { statusCode: 400, body: JSON.stringify({ message: "This time slot is already booked for this table" }) };

    const newBooking = new Booking({ restaurantId, tableId, tableNumber, date, time, endTime, customerName, customerEmail, customerPhone });
    await newBooking.save();

    return { statusCode: 200, body: JSON.stringify({ message: "Booking saved successfully", booking: newBooking }) };
  } catch (error) {
    console.error(error);
    return { statusCode: 500, body: JSON.stringify({ message: "Server error" }) };
  }
};
