import mongoose from "mongoose";

const MONGODB_URI =
  "mongodb+srv://sujeethparamasivam_db_user:sujeeth7500@table.irsiw2i.mongodb.net/restaurant_booking";

let isConnected = false;

export async function connectDB() {
  if (isConnected) return;
  await mongoose.connect(MONGODB_URI);
  isConnected = true;
}
